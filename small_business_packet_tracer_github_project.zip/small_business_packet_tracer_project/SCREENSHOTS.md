# Packet Tracer evidence screenshots

Capture these from your own completed Packet Tracer simulation and save them in `images/`:

1. `packet-tracer-full-topology.png` — entire workspace, with readable device names and links.
2. `vlan-configuration.png` — `show vlan brief` on S1.
3. `router-subinterfaces.png` — `show ip interface brief` on R1.
4. `dhcp-verification.png` — client IP configuration and `show ip dhcp binding`.
5. `guest-acl-test.png` — guest-to-internal ping blocked and ACL counters.
6. `connectivity-tests.png` — successful authorized internal connectivity tests.

Do not use the illustrative SVG as proof of a completed Packet Tracer simulation.

# Small Business Network Design & Implementation (Cisco Packet Tracer)

A practical networking portfolio project that designs, configures, tests, and troubleshoots a segmented network for a small business.

![Small business network topology](images/small-business-network-topology.svg)

## 1. Project overview

**Scenario:** A small company has separate Administration, Sales, IT, Server, and Guest Wi-Fi users. The existing flat network makes troubleshooting difficult and allows guest devices to reach internal resources. The goal is to build a manageable network with VLAN segmentation, inter-VLAN routing, DHCP, basic perimeter protection, and documented testing.

**Platform:** Cisco Packet Tracer  
**Suggested devices:** 1 Cisco 2911 router, 1 Cisco 2960 switch, 1 server, 1 wireless access point, PCs/laptops, and an optional ISP/cloud object.

> This is a lab design. Create the `.pkt` simulation yourself in Packet Tracer and replace the example test outcomes with the results you actually observe.

## 2. Objectives

- Separate departments using VLANs and subnets.
- Enable authorized communication between internal VLANs.
- Provide automatic IPv4 addressing through DHCP.
- Isolate Guest Wi-Fi from private business networks.
- Provide a basic, documented router security baseline.
- Verify connectivity and record troubleshooting evidence.

## 3. Topology and addressing plan

See the [network topology image](images/small-business-network-topology.svg).

| VLAN | Department / purpose | Network | Default gateway |
|---|---|---|---|
| 10 | Administration | `192.168.10.0/24` | `192.168.10.1` |
| 20 | Sales | `192.168.20.0/24` | `192.168.20.1` |
| 30 | IT | `192.168.30.0/24` | `192.168.30.1` |
| 40 | Servers | `192.168.40.0/24` | `192.168.40.1` |
| 50 | Guest Wi-Fi | `192.168.50.0/24` | `192.168.50.1` |

Example static server address: `192.168.40.10/24`, gateway `192.168.40.1`.

## 4. Build the topology in Packet Tracer

1. Open Cisco Packet Tracer and create a new project.
2. Add one 2911 router (`R1`) and one 2960 switch (`S1`).
3. Add representative PCs for Admin, Sales, and IT; add a server and wireless access point.
4. Connect `R1 G0/0` to `S1 G0/1` using copper straight-through. Connect end devices to switch access ports.
5. Connect the server to a switch port reserved for VLAN 40. Connect the access point to a port reserved for VLAN 50.
6. Save the project as `Small-Business-Network.pkt`.
7. Label devices, interfaces, VLANs, and subnet ranges in the Packet Tracer workspace.

**Example switch-port allocation** (adjust to match your actual cabling):

| Switch port | Connected device | VLAN / mode |
|---|---|---|
| Fa0/1–Fa0/4 | Admin PCs / printer | Access VLAN 10 |
| Fa0/5–Fa0/8 | Sales PCs | Access VLAN 20 |
| Fa0/9–Fa0/11 | IT PCs | Access VLAN 30 |
| Fa0/12 | Server | Access VLAN 40 |
| Fa0/13 | Wireless AP | Access VLAN 50 |
| Gi0/1 | Router R1 G0/0 | 802.1Q trunk |

## 5. Configure the switch

Enter the following on `S1` (change port ranges if your topology differs):

```text
enable
configure terminal
hostname S1

vlan 10
 name ADMIN
vlan 20
 name SALES
vlan 30
 name IT
vlan 40
 name SERVERS
vlan 50
 name GUEST

interface range fa0/1-4
 switchport mode access
 switchport access vlan 10
 spanning-tree portfast
exit

interface range fa0/5-8
 switchport mode access
 switchport access vlan 20
 spanning-tree portfast
exit

interface range fa0/9-11
 switchport mode access
 switchport access vlan 30
 spanning-tree portfast
exit

interface fa0/12
 switchport mode access
 switchport access vlan 40
 spanning-tree portfast
exit

interface fa0/13
 switchport mode access
 switchport access vlan 50
 spanning-tree portfast
exit

interface gi0/1
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30,40,50
 no shutdown
exit

end
write memory
```

If Packet Tracer's selected switch uses different interface names, use `show interfaces status` and adapt the commands. Some switch models require an encapsulation command; many 2960 models use 802.1Q automatically.

## 6. Configure router-on-a-stick

On `R1`, create one subinterface per VLAN. The physical interface and subinterface names must match the router model and cable used.

```text
enable
configure terminal
hostname R1

interface gigabitEthernet0/0
 no shutdown
exit

interface gigabitEthernet0/0.10
 encapsulation dot1Q 10
 ip address 192.168.10.1 255.255.255.0
exit

interface gigabitEthernet0/0.20
 encapsulation dot1Q 20
 ip address 192.168.20.1 255.255.255.0
exit

interface gigabitEthernet0/0.30
 encapsulation dot1Q 30
 ip address 192.168.30.1 255.255.255.0
exit

interface gigabitEthernet0/0.40
 encapsulation dot1Q 40
 ip address 192.168.40.1 255.255.255.0
exit

interface gigabitEthernet0/0.50
 encapsulation dot1Q 50
 ip address 192.168.50.1 255.255.255.0
exit

end
write memory
```

## 7. Configure DHCP

The following example reserves addresses `.1` to `.20` in each subnet for gateways, servers, printers, and static infrastructure. Configure DHCP pools on `R1`:

```text
configure terminal

ip dhcp excluded-address 192.168.10.1 192.168.10.20
ip dhcp excluded-address 192.168.20.1 192.168.20.20
ip dhcp excluded-address 192.168.30.1 192.168.30.20
ip dhcp excluded-address 192.168.40.1 192.168.40.20
ip dhcp excluded-address 192.168.50.1 192.168.50.20

ip dhcp pool ADMIN
 network 192.168.10.0 255.255.255.0
 default-router 192.168.10.1
 dns-server 192.168.40.10

ip dhcp pool SALES
 network 192.168.20.0 255.255.255.0
 default-router 192.168.20.1
 dns-server 192.168.40.10

ip dhcp pool IT
 network 192.168.30.0 255.255.255.0
 default-router 192.168.30.1
 dns-server 192.168.40.10

ip dhcp pool GUEST
 network 192.168.50.0 255.255.255.0
 default-router 192.168.50.1
 dns-server 8.8.8.8

end
write memory
```

Give the server a static address such as `192.168.40.10/24`. Enable DNS or file services only if those services are part of your simulation. If the server is not configured as DNS, use a reachable DNS service or omit the DNS option in the pools.

## 8. Apply a Guest isolation ACL

This example blocks Guest VLAN traffic to the internal `192.168.0.0/16` address space and permits other IPv4 destinations. Apply it inbound on the Guest subinterface:

```text
configure terminal
ip access-list extended GUEST-IN
 deny ip 192.168.50.0 0.0.0.255 192.168.0.0 0.0.255.255
 permit ip 192.168.50.0 0.0.0.255 any
exit

interface gigabitEthernet0/0.50
 ip access-group GUEST-IN in
exit

end
write memory
```

**Important:** This is a basic lab policy, not a complete production firewall. Add explicit rules for required DNS, DHCP, management, and other services if your design requires them. Test the ACL carefully. Do not assume internet access works until an ISP path, routing, and (if required) NAT have been configured.

## 9. Verification and testing plan

Run these commands and save screenshots of the actual outputs:

**On the switch**
```text
show vlan brief
show interfaces trunk
show interfaces status
```

**On the router**
```text
show ip interface brief
show ip route
show ip dhcp binding
show access-lists
```

**On client PCs**
```text
ipconfig
ping 192.168.10.1
ping 192.168.20.1
ping 192.168.40.10
```

Suggested acceptance tests:

| Test | Expected result |
|---|---|
| Admin PC receives DHCP address | `192.168.10.x/24` |
| Sales PC receives DHCP address | `192.168.20.x/24` |
| IT PC receives DHCP address | `192.168.30.x/24` |
| Admin PC pings its gateway | Success |
| Authorized internal PC reaches server | Success, if server/service is configured |
| Guest PC reaches an internal server | Blocked by Guest ACL |
| Guest PC reaches an external test destination | Only succeeds after ISP routing/NAT is configured |

Record actual results, not just expected results. A failed test is useful evidence when accompanied by the observed output and the fix.

## 10. Troubleshooting: issues to investigate and possible solutions

The following are common lab faults to reproduce or check. They are not claims that every issue occurred in this build.

| Symptom | Likely cause | Troubleshooting / solution |
|---|---|---|
| PC receives `169.254.x.x` | DHCP pool missing, wrong VLAN, trunk issue | Check `show vlan brief`, pool configuration, trunk allowed VLANs, and router subinterface status |
| PC cannot ping its gateway | Wrong IP/mask, interface down, wrong access VLAN | Check `ipconfig`, `show ip interface brief`, port assignment, and cable |
| Devices in different VLANs cannot communicate | Missing router subinterface or 802.1Q mismatch | Verify VLAN ID in `encapsulation dot1Q`, trunk state, and gateway IP |
| Server is unreachable | Wrong static IP/gateway or server port VLAN | Verify server addressing, VLAN 40 access port, and router route table |
| Guest can access private network | ACL absent, attached in wrong direction, or incorrect rule order | Check `show access-lists` and `show running-config`; apply inbound on Guest subinterface |
| Guest has no internet access | No ISP route, NAT, or upstream connectivity | Configure and verify ISP routing and NAT; test each hop |
| Intermittent connectivity | Duplicate IP, bad cable, speed/duplex mismatch, or loop | Check ARP/IP assignments, interface counters, cabling, and spanning tree |

### A structured troubleshooting method

1. **Identify:** Record the affected user, device, VLAN, IP address, time, and exact symptom.
2. **Check physical connectivity:** Inspect cable status, link lights, and interface state.
3. **Check Layer 2:** Confirm access VLAN membership and trunk VLAN allowance.
4. **Check Layer 3:** Validate IP address, subnet mask, gateway, routing, and subinterfaces.
5. **Check services and policy:** Review DHCP, DNS, server services, and ACL rules.
6. **Fix and retest:** Change one item at a time, repeat the failed test, and verify that unrelated VLANs still work.
7. **Document:** Record root cause, evidence, corrective action, and final outcome.

## 11. Security and operational recommendations

- Use strong administrative passwords and restrict management access to the IT VLAN.
- Disable unused switch ports and place them in an unused parking VLAN.
- Use SSH rather than Telnet where supported.
- Back up router and switch configurations after approved changes.
- Keep firmware and endpoint operating systems updated.
- Use endpoint protection, least privilege, and MFA where available.
- Monitor logs, device availability, and configuration changes.
- Maintain tested backups and a documented recovery procedure.
- In production, use a properly sized firewall and review ACLs with the business owner.

## 12. Suggested GitHub repository structure

```text
small-business-packet-tracer-network/
├── README.md
├── index.html
├── Small-Business-Network.pkt
├── images/
│   ├── small-business-network-topology.svg
│   ├── packet-tracer-full-topology.png
│   ├── vlan-configuration.png
│   ├── router-subinterfaces.png
│   ├── dhcp-verification.png
│   ├── guest-acl-test.png
│   └── connectivity-tests.png
└── configs/
    ├── router-R1.txt
    └── switch-S1.txt
```

## 13. Add clear screenshots to GitHub

After building and testing the Packet Tracer simulation:

1. Arrange the complete topology so device names and links are readable.
2. Use Packet Tracer's screenshot/export facility or your operating system's screenshot tool.
3. Save genuine screenshots in the `images/` folder using the filenames above.
4. Add them to GitHub and commit them with the `.pkt` file and configuration text files.
5. Replace or supplement the illustrative SVG above with your actual Packet Tracer screenshots.

Example HTML image embed for the README:

```html
<p align="center">
  <img src="images/packet-tracer-full-topology.png"
       alt="Full Packet Tracer small business network topology"
       width="100%">
</p>
```

For a clickable image that opens the full-size screenshot:

```html
<p align="center">
  <a href="images/packet-tracer-full-topology.png">
    <img src="images/packet-tracer-full-topology.png"
         alt="Click to view the full network topology"
         width="100%">
  </a>
</p>
```

## 14. Project outcome

The intended outcome is a segmented small-business network with department-specific VLANs, centralized inter-VLAN routing, automatic addressing, a server segment, and restricted guest access. The project demonstrates network planning, Cisco device configuration, security policy implementation, verification, and structured troubleshooting.

**Portfolio note:** Add your own Packet Tracer `.pkt` file, configuration outputs, and screenshots before describing the project as fully implemented. Clearly distinguish planned behavior from tests you personally completed.
